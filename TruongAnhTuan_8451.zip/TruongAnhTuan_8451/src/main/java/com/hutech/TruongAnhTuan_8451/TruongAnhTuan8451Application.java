package com.hutech.TruongAnhTuan_8451;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TruongAnhTuan8451Application {

	public static void main(String[] args) {
		SpringApplication.run(TruongAnhTuan8451Application.class, args);
	}

}
