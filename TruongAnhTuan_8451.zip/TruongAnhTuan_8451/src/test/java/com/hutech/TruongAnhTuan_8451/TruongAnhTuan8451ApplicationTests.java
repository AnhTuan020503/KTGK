package com.hutech.TruongAnhTuan_8451;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TruongAnhTuan8451ApplicationTests {

	@Test
	void contextLoads() {
	}

}
